<?php
$host = "localhost";
$db_name = "eneg1777_careersenergeek";
$username = "eneg1777_careersenergeek";
$password = "careersenergeek";

$conn = new mysqli($host, $username, $password, $db_name);
?>